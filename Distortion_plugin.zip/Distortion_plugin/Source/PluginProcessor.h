/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>

//==============================================================================
/**
*/
class DistortionAudioProcessor  : public AudioProcessor,
private ValueTree::Listener
{
public:
    //==============================================================================
    DistortionAudioProcessor();
    ~DistortionAudioProcessor();

    //==============================================================================
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;

   #ifndef JucePlugin_PreferredChannelConfigurations
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
   #endif

    void processBlock (AudioBuffer<float>&, MidiBuffer&) override;

    //==============================================================================
    AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override;

    //==============================================================================
    const String getName() const override;

    bool acceptsMidi() const override;
    bool producesMidi() const override;
    bool isMidiEffect() const override;
    double getTailLengthSeconds() const override;

    //==============================================================================
    int getNumPrograms() override;
    int getCurrentProgram() override;
    void setCurrentProgram (int index) override;
    const String getProgramName (int index) override;
    void changeProgramName (int index, const String& newName) override;

    //==============================================================================
    void getStateInformation (MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;
    
    /* Get current Value tree state*/
    AudioProcessorValueTreeState& getState();
    
    /* Pre & Post LowPass Filter*/
    AudioParameterFloat *mPreLP, *mPostLP;
    
    /* Update filter setup*/
    void updateFilterProcess();
    
    /* OverSampling*/
    AudioParameterBool* mOvsmplParam;
    
    /* Waveshaper */
    static float clip (float x) {
        return jmax(-1.f, jmin(1.f, x));
    }
    AudioParameterChoice* mWaveshaperParam;
    
    /* Parameters declaration*/
    AudioProcessorValueTreeState mState;

private:
    
    
    AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    //AudioParameterInt* mTypeID;
    
    /* Value Tree Listener*/
    std::atomic<bool> mShouldUpdate {
        false
    };
    void valueTreePropertyChanged (ValueTree& treeWhosePropertyHasChanged, const Identifier& property) override;
    
    void valueTreeChildAdded (ValueTree& parentTree,
    ValueTree& childWhichHasBeenAdded) override;
    void valueTreeChildRemoved (ValueTree& parentTree,
    ValueTree& childWhichHasBeenRemoved,
    int indexFromWhichChildWasRemoved) override;
    void valueTreeChildOrderChanged (ValueTree& parentTreeWhoseChildrenHaveMoved,
                                     int oldIndex, int newIndex) override;
    void valueTreeParentChanged (ValueTree& treeWhoseParentHasChanged) override;
    
    /* Threshold for soft clipping */
    float mSoftClipThreshold = 2.f / 3.f;
    
    /* Oversampling*/
    std::unique_ptr<dsp::Oversampling<float>> mOvSampling;
    std::atomic<bool> alreadyOversampled {
        false
    };
    
    
    /* Filtering */
    using Filter = dsp::ProcessorDuplicator<dsp::StateVariableFilter::Filter<float>, dsp::StateVariableFilter::Parameters<float>>;
    Filter mPreLPFilter, mPostLPFilter;
    double mLastSampleRate;
    
    
    //AudioBuffer<float> mMixer;
    /* Active process*/
    std::atomic<bool> mActive {
        false
    };
    
    /* Waveshaper*/
    static constexpr size_t numWaveShapers = 2;
    dsp::WaveShaper<float> mWaveShapers[numWaveShapers];
    dsp::WaveShaper<float> mClipping;
    
    struct Controls {
        float input_att;
        float drive;
        float mix;
        float outGain;
        int typeID = 1;
    } controls;
    
    
    /* Distortion */
    void makeDistortion(float *channelData, Controls controls);
    
    //==============================================================================
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DistortionAudioProcessor)
};
