/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class DistortionAudioProcessorEditor  : public AudioProcessorEditor
{
public:
    DistortionAudioProcessorEditor (DistortionAudioProcessor&);
    ~DistortionAudioProcessorEditor();

    //==============================================================================
    void paint (Graphics&) override;
    void resized() override;

private:
    
    //void comboBoxChanged(ComboBox* changedComboBox) override;
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    DistortionAudioProcessor& processor;
    
    /* Slider declaration */
    /* Drive knob - amount of distortion we want*/
    ScopedPointer<Slider> mInputSlider;
    /* Range know - distance to a target; portion of grungy sound*/
    ScopedPointer<Slider> mDriveSlider;
    /* Blend (mix) knob */
    ScopedPointer<Slider> mBlendSlider;
    /* Gain knob*/
    ScopedPointer<Slider> mGainSlider;
    /* Pre CutOff knob*/
    ScopedPointer<Slider> mPreCutOffSlider;
    /* Post CutOff knob*/
    ScopedPointer<Slider> mPostCutOffSlider;
    
    /* Distortion Type Choice ComboBox */
    ComboBox mDistortionType;
    
    /* Checkbox oversample*/
    ToggleButton mOversampleButton {"Oversample"};
    //ToggleButton mFilterEnableButton;
    
    /* Slider attachement declaration: for xml to save presets */
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mInputAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mDriveAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mBlendAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mGainAttachment;
    ScopedPointer<AudioProcessorValueTreeState::ComboBoxAttachment> mTypeAttachment;
    
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mPreCutOffAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mPostCutoffAttachment;
    ScopedPointer<AudioProcessorValueTreeState::ButtonAttachment> mEnableAttachment;
    
    /* Labels */
    Label  rangeLabel, driveLabel, blendLabel, gainLabel, postCutOffLabel, preCutOffLabel,
    waveshaperLabel, oversampleLabel;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DistortionAudioProcessorEditor)
};
