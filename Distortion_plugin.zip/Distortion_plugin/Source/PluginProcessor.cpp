/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin processor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
DistortionAudioProcessor::DistortionAudioProcessor()
#ifndef JucePlugin_PreferredChannelConfigurations
     : AudioProcessor (BusesProperties()
                     #if ! JucePlugin_IsMidiEffect
                      #if ! JucePlugin_IsSynth
                       .withInput  ("Input",  AudioChannelSet::stereo(), true)
                      #endif
                       .withOutput ("Output", AudioChannelSet::stereo(), true)
                     #endif
                       ),
mState(*this, nullptr, "parameters", createParameterLayout()),
mWaveShapers { {std::tanh }, { dsp::FastMathApproximations::tanh}},
mClipping { clip }
#endif
{
    mState.state.addListener(this);
    mOvSampling.reset (new dsp::Oversampling<float>(getTotalNumInputChannels(), 2, dsp::Oversampling<float>::filterHalfBandPolyphaseIIR, false));
    addParameter(mOvsmplParam = new AudioParameterBool ("oversampling", "Oversampling", false));
    addParameter ( mWaveshaperParam = new AudioParameterChoice ( "waveshaper", "Waveshaper", { "std::tanh", "Fast tanh Approx"}, 0));
    
}

DistortionAudioProcessor::~DistortionAudioProcessor()
{
    
}

//==============================================================================
const String DistortionAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

bool DistortionAudioProcessor::acceptsMidi() const
{
   #if JucePlugin_WantsMidiInput
    return true;
   #else
    return false;
   #endif
}

bool DistortionAudioProcessor::producesMidi() const
{
   #if JucePlugin_ProducesMidiOutput
    return true;
   #else
    return false;
   #endif
}

bool DistortionAudioProcessor::isMidiEffect() const
{
   #if JucePlugin_IsMidiEffect
    return true;
   #else
    return false;
   #endif
}

double DistortionAudioProcessor::getTailLengthSeconds() const
{
    return 0.0;
}

int DistortionAudioProcessor::getNumPrograms()
{
    return 1;   // NB: some hosts don't cope very well if you tell them there are 0 programs,
                // so this should be at least 1, even if you're not really implementing programs.
}

int DistortionAudioProcessor::getCurrentProgram()
{
    return 0;
}

void DistortionAudioProcessor::setCurrentProgram (int index)
{
}

const String DistortionAudioProcessor::getProgramName (int index)
{
    return {};
}

void DistortionAudioProcessor::changeProgramName (int index, const String& newName)
{
}

//==============================================================================
void DistortionAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    mLastSampleRate = sampleRate;
    dsp::ProcessSpec spec;
    spec.sampleRate = sampleRate;
    spec.maximumBlockSize = static_cast<uint32>(samplesPerBlock);
    spec.numChannels = static_cast<uint32>(getMainBusNumOutputChannels());
    
    /* initialize LP Filters */
    mPreLPFilter.reset();
    updateFilterProcess();
    mPreLPFilter.prepare(spec);
    
    mPostLPFilter.reset();
    updateFilterProcess();
    mPostLPFilter.prepare(spec);
    
    mActive = true;
    
    mOvSampling->initProcessing(static_cast<size_t>(samplesPerBlock));
    
    mOvSampling->reset();
    
}

void DistortionAudioProcessor::releaseResources()
{
    // When playback stops, you can use this as an opportunity to free up any
    // spare memory, etc.
}

#ifndef JucePlugin_PreferredChannelConfigurations
bool DistortionAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
  #if JucePlugin_IsMidiEffect
    ignoreUnused (layouts);
    return true;
  #else
    // This is the place where you check if the layout is supported.
    // In this template code we only support mono or stereo.
    if (layouts.getMainOutputChannelSet() != AudioChannelSet::mono()
     && layouts.getMainOutputChannelSet() != AudioChannelSet::stereo())
        return false;

    // This checks if the input layout matches the output layout
   #if ! JucePlugin_IsSynth
    if (layouts.getMainOutputChannelSet() != layouts.getMainInputChannelSet())
        return false;
   #endif

    return true;
  #endif
}
#endif

void DistortionAudioProcessor::processBlock (AudioBuffer<float>& buffer, MidiBuffer& midiMessages)
{
    if (mActive == false)
        return;
    
    updateFilterProcess();
    
    ScopedNoDenormals noDenormals;
    auto totalNumInputChannels  = getTotalNumInputChannels();
    auto totalNumOutputChannels = getTotalNumOutputChannels();
    

    // In case we have more outputs than inputs, this code clears any output
    // channels that didn't contain input data, (because these aren't
    // guaranteed to be empty - they may contain garbage).
    // This is here to avoid people getting screaming feedback
    // when they first compile a plugin, but obviously you don't need to keep
    // this code if your algorithm always overwrites all the output channels.
    for (auto i = totalNumInputChannels; i < totalNumOutputChannels; ++i)
        buffer.clear (i, 0, buffer.getNumSamples());
    
    /* update oversampling*/
    auto newOvsmpl = mOvsmplParam->get();
    if (newOvsmpl != alreadyOversampled) {
        alreadyOversampled = newOvsmpl;
        mOvSampling->reset();
    }
    
    
    /* Update parameters due to Listener respond*/
    
    
    if (mShouldUpdate) {
        controls.input_att = *mState.getRawParameterValue("input_att");
        controls.drive = *mState.getRawParameterValue("drive");
        controls.mix = *mState.getRawParameterValue("blend");
        controls.outGain = *mState.getRawParameterValue("gain");
        controls.typeID = *mState.getRawParameterValue("type");
    }
    
    /* Filter set up*/
    dsp::AudioBlock<float> block (buffer);
    
    /*Stereo mode */
    block = block.getSubsetChannelBlock(0, 2);
    
    
    /* Pre-Filtering*/
    updateFilterProcess();
    dsp::ProcessContextReplacing<float> context (block);
    mPreLPFilter.process(context);

    
    /*upsampling*/
    dsp::AudioBlock<float> overSampledBlock;
    setLatencySamples (alreadyOversampled ? roundToInt (mOvSampling->getLatencyInSamples()) : 0);
    if (alreadyOversampled)
        overSampledBlock = mOvSampling->processSamplesUp(context.getOutputBlock());
    
    /* get new Buffer */
    AudioBuffer<float> ovsBuffer (
                                  (float* []) { overSampledBlock.getChannelPointer(0), overSampledBlock.getChannelPointer(1) }, 2, static_cast<int> (overSampledBlock.getNumSamples()));
    
    for (int channel = 0; channel < totalNumInputChannels; ++channel)
    {
        
        if (alreadyOversampled) {
            auto* channelData = ovsBuffer.getWritePointer (channel);
            for (int sample = 0; sample < ovsBuffer.getNumSamples(); ++sample)
            {
                makeDistortion(channelData, controls);
                channelData++;
            }
        } else {
            auto* channelData = buffer.getWritePointer (channel);;
            for (int sample = 0; sample < buffer.getNumSamples(); ++sample)
            {
                makeDistortion(channelData, controls);
                channelData++;
            }
        }
    }
    
    
    updateFilterProcess();
    
    /* downsampling*/
    if (alreadyOversampled)
        mOvSampling->processSamplesDown(context.getOutputBlock());
    
    /* Post-filtering */
    mPostLPFilter.process(context);
    
    
    
    
    overSampledBlock.clear();
    
}
        

//==============================================================================
bool DistortionAudioProcessor::hasEditor() const
{
    return true; // (change this to false if you choose to not supply an editor)
}

AudioProcessorEditor* DistortionAudioProcessor::createEditor()
{
    return new DistortionAudioProcessorEditor (*this);
}

//==============================================================================
void DistortionAudioProcessor::getStateInformation (MemoryBlock& destData)
{
    // You should use this method to store your parameters in the memory block.
    // You could do that either as raw data, or use the XML or ValueTree classes
    // as intermediaries to make it easy to save and load complex data.
    
    MemoryOutputStream stream(destData,true);
    mState.state.writeToStream(stream);
}

void DistortionAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    // You should use this method to restore your parameters from this memory block,
    // whose contents will have been created by the getStateInformation() call.
    
    ValueTree tree = ValueTree::readFromData(data, sizeInBytes);
    
    if (tree.isValid()){
        mState.state = tree;
    }
}

AudioProcessorValueTreeState& DistortionAudioProcessor::getState() {
    return mState;
}

AudioProcessorValueTreeState::ParameterLayout DistortionAudioProcessor::createParameterLayout()
{
     std::vector<std::unique_ptr<RangedAudioParameter>> parameters;
    NormalisableRange<float> inputRange (0.f,1.f,0.0001);
    NormalisableRange<float> driveRange (0.f,3000.f,0.0001);
    NormalisableRange<float> blendRange (0.f,1.f,0.0001);
    NormalisableRange<float> gainRange (0.f,3.f,0.0001);
    NormalisableRange<float> cutoffRange (20.f,20000.f,0.001);
    
    parameters.push_back(std::make_unique<AudioParameterFloat>("input_att",
                                                               "Input",
                                                               inputRange,
                                                               1.0));
    parameters.push_back(std::make_unique<AudioParameterFloat>("drive",
                                                               "Drive",
                                                               driveRange,
                                                               1.0));
    parameters.push_back(std::make_unique<AudioParameterFloat>("blend",
                                                               "Blend",
                                                               blendRange,
                                                               1.0));
    parameters.push_back(std::make_unique<AudioParameterFloat>("gain",
                                                               "Output Gain",
                                                               gainRange,
                                                               1.0));
    parameters.push_back(std::make_unique<AudioParameterInt>("type",
                                                             "Type",
                                                             1, 5, 1));
    parameters.push_back(std::make_unique<AudioParameterFloat>("postlpfcutoff",
                                                                "Post-Cutoff",
                                                               cutoffRange,
                                                               600.f));
    parameters.push_back(std::make_unique<AudioParameterFloat>("prelpfcutoff",
                                                               "Pre-Cutoff",
                                                               cutoffRange,
                                                               600.f));
    
    return { parameters.begin(), parameters.end() };
}

void DistortionAudioProcessor::valueTreePropertyChanged (ValueTree& treeWhosePropertyHasChanged, const Identifier& property) {
    mShouldUpdate = true;
}


void DistortionAudioProcessor::valueTreeChildAdded (ValueTree& parentTree,
ValueTree& childWhichHasBeenAdded) {
    
}

void DistortionAudioProcessor::valueTreeChildRemoved (ValueTree& parentTree,
ValueTree& childWhichHasBeenRemoved,
                            int indexFromWhichChildWasRemoved) {
    
    
}
void DistortionAudioProcessor::valueTreeChildOrderChanged (ValueTree& parentTreeWhoseChildrenHaveMoved,
                                 int oldIndex, int newIndex) {
    
}
void DistortionAudioProcessor::valueTreeParentChanged (ValueTree& treeWhoseParentHasChanged) {
    
}

void DistortionAudioProcessor::updateFilterProcess() {
    
    //mVolume.setValue(Decibels::decibelsToGain(*mState.getRawParameterValue("gain"))) ;

    float postCutOff = *mState.getRawParameterValue("postlpfcutoff");
    float preCutOff = *mState.getRawParameterValue("prelpfcutoff");
    
    mPreLPFilter.state->type = dsp::StateVariableFilter::Parameters<float>::Type::highPass;
    mPreLPFilter.state->setCutOffFrequency (mLastSampleRate, preCutOff, 2.f);
    
    mPostLPFilter.state->type = dsp::StateVariableFilter::Parameters<float>::Type::lowPass;
    mPostLPFilter.state->setCutOffFrequency (mLastSampleRate, postCutOff, 2.f);

    
}

void DistortionAudioProcessor::makeDistortion (float *channelData, Controls controls)
{
    /* save clean signal */
    float cleanSignl = *channelData;
    float output = *channelData;
    float input = *channelData;
    
    /*amplify signal*/
    float inGain = controls.input_att * controls.drive;
    input *= inGain;
    
    switch(controls.typeID) {
        
        case 1: {
            /* hard clipping */
            //output = jlimit(-1.f, 1.f, output);
            if (input < -1.f) {
                output = -1.f;
            } else if (input > 1.f) {
                output = 1.f;
            }
            break;
        }
        case 2: {
            /* soft clipping */
            if (input < -1.f) {
                output = -mSoftClipThreshold;
            } else if (input > 1.f) {
                output = mSoftClipThreshold;
            } else {
                output = input - (input*input*input)/3.f;
            }
            break;
        }
        case 3: {
               /* Soft Clipping Exponential */
            if (input > 0) {
                output = 1.f - expf(-input);
            } else {
                output = -1.f + expf(input);
            }
            break;
            }
        case 4: {
            /* Half-wave Rectifier */
            if (input > 0) {
                output = input;
            } else {
                output = 0;
            }
            break;
        }
        case 5:{
            /* atan*/
            output = (2.f/float_Pi) * atan(input);
                      break;
        }
        default:
            output = input;
            break;
    }
    
   *channelData =  (((output * controls.mix) + (cleanSignl *(1.f - controls.mix))) / 2.f) * controls.outGain;

}

//==============================================================================
// This creates new instances of the plugin..


AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new DistortionAudioProcessor();
}

