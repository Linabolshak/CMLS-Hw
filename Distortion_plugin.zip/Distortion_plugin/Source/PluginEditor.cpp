/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
DistortionAudioProcessorEditor::DistortionAudioProcessorEditor (DistortionAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)

{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (600, 300);

    addAndMakeVisible(mInputSlider = new Slider("Input"));
    mInputSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mInputSlider->setTextBoxStyle((Slider::TextEntryBoxPosition::NoTextBox), true, 0, 0);
    mInputSlider->setValue(0.5f);
    mInputSlider->setPopupDisplayEnabled(true, true, this);
    //rangeLabel.setJustificationType (Justification::centredBottom);
    //rangeLabel.attachToComponent (mInputSlider.get(), true);
    mInputSlider->setBounds(((getWidth()/6.f) * 1.f) - 80, ((getHeight()/3.f) - (100/2.f)), 70, 70);
    
    addAndMakeVisible(mDriveSlider= new Slider("Drive"));
    mDriveSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mDriveSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    mDriveSlider->setPopupDisplayEnabled(true, true, this);
    mDriveSlider->setValue(1.f);
    //driveLabel.setJustificationType (Justification::centred);
    //driveLabel.attachToComponent (mDriveSlider.get(), true);
    mDriveSlider->setBounds(((getWidth()/6.f) * 2) - 80, ((getHeight()/3.f) - (100/2.f)), 70, 70);
    
    addAndMakeVisible(mBlendSlider= new Slider("Blend"));
    mBlendSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mBlendSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    mBlendSlider->setPopupDisplayEnabled(true, true, this);
    mBlendSlider->setValue(1.f);
    //blendLabel.setJustificationType (Justification::centredTop);
    //blendLabel.attachToComponent (mBlendSlider.get(), true);
    mBlendSlider->setBounds(((getWidth()/6) * 3) - 80, ((getHeight()/3) - (100/2)), 70, 70);
    
    addAndMakeVisible(mGainSlider= new Slider("Gain"));
    mGainSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mGainSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    mGainSlider->setPopupDisplayEnabled(true, true, this);
    mGainSlider->setValue(1.f);
    //gainLabel.setJustificationType (Justification::centredLeft);
    //gainLabel.attachToComponent (mGainSlider.get(), true);
    mGainSlider->setBounds(((getWidth()/6) * 4) - 80, ((getHeight()/3) - (100/2)), 70, 70);
    
    
    mDistortionType.addItem("Hard Clipping", 1);
    mDistortionType.addItem("Soft Clipping", 2);
    mDistortionType.addItem("Soft Clipping Exponential", 3);
    mDistortionType.addItem("Half-wave Rectifier", 4);
    mDistortionType.addItem("Arctangent", 5);
    addAndMakeVisible(&mDistortionType);
    mDistortionType.setSelectedItemIndex(1);
    //mDistortionType.addListener(this);
    mDistortionType.setBounds((getWidth()/2.f)-100, (getHeight()/2 + 30),200, 20);

    addAndMakeVisible(mPostCutOffSlider = new Slider("Post-Cutoff"));
    mPostCutOffSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mPostCutOffSlider->setTextBoxStyle ((Slider::TextEntryBoxPosition::NoTextBox), true, 0, 0);
    mPostCutOffSlider->setValue(600.f);
    mPostCutOffSlider->setPopupDisplayEnabled(true, true, this);
    //postCutOffLabel.setJustificationType (Justification::bottomLeft);
    //postCutOffLabel.attachToComponent (mPostCutOffSlider.get(), true);
    mPostCutOffSlider->setBounds(((getWidth()/6.f) * 5.f) - 80, ((getHeight()/3.f) - 100/2), 70, 70);
    
    addAndMakeVisible(mPreCutOffSlider = new Slider("Pre-Cutoff"));
    mPreCutOffSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mPreCutOffSlider->setTextBoxStyle ((Slider::TextEntryBoxPosition::NoTextBox), true, 0, 0);
    mPreCutOffSlider->setValue(3500.f);
    mPreCutOffSlider->setPopupDisplayEnabled(true, true, this);
    mPreCutOffSlider->setBounds(((getWidth()/6.f) * 6) - 80, ((getHeight()/3.f) - 100/2), 70, 70);
    //addAndMakeVisible(preCutOffLabel);
    //preCutOffLabel.setJustificationType (Justification::centredBottom);
    //preCutOffLabel.attachToComponent (mPreCutOffSlider.get(), true);
    
    
    addAndMakeVisible(mOversampleButton);
    mOversampleButton.onClick = [this] { processor.mOvsmplParam->operator=(mOversampleButton.getToggleState()); };
    mOversampleButton.setToggleState(processor.mOvsmplParam->get(), NotificationType::dontSendNotification);
    //mOversampleButton.setBounds(getWidth()/6, getHeight(), 200, 20);
    

    
    mInputAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "input_att", *mInputSlider);
    mDriveAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "drive", *mDriveSlider);
    mBlendAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "blend", *mBlendSlider);
    mGainAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"gain", *mGainSlider);
     mTypeAttachment = new AudioProcessorValueTreeState::ComboBoxAttachment(p.getState(),"type", mDistortionType);
    mPostCutoffAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"postlpfcutoff", *mPostCutOffSlider);
    mPreCutOffAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(),"prelpfcutoff", *mPreCutOffSlider);
}

DistortionAudioProcessorEditor::~DistortionAudioProcessorEditor()
{
}

//==============================================================================
void DistortionAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));
    
    auto area = getLocalBounds();
    g.setGradientFill(ColourGradient(Colours::dimgrey,0,0,Colours::silver,0, getHeight()/1.5f,false));
       g.fillRect(area.toFloat());


    g.setColour (Colours::white);
    g.setFont (15.0f);
    //g.drawFittedText ("Hello World!", getLocalBounds(), Justification::centred, 1);
    g.drawText("Input", (((getWidth()/6) * 1) - 80), ((getHeight()/3) +5), 70, 70, Justification::centred,true);
    g.drawText("Drive", ((getWidth()/6) * 2) - 80, ((getHeight()/3) +5), 70, 70, Justification::centred,true);
    g.drawText("Blend", ((getWidth()/6) * 3) - 80, ((getHeight()/3) +5), 70, 70, Justification::centred);
    g.drawText("Out Gain", ((getWidth()/6) * 4) - 80, ((getHeight()/3) +5), 70, 70, Justification::centred);
    g.drawText("Post CutOff", ((getWidth()/6) * 5) - 80, ((getHeight()/3) +5), 70, 70, Justification::centred);
    g.drawText("Pre CutOff", ((getWidth()/6) * 6) - 80, ((getHeight()/3) +5), 70, 70, Justification::centred);
}


void DistortionAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    auto bounds = getLocalBounds().reduced(10);
    bounds.removeFromTop(20);
    bounds.removeFromLeft(125);
    
    auto buttonSlice = bounds.removeFromTop(30);
    mOversampleButton.setSize(200, buttonSlice.getHeight());
    mOversampleButton.setCentrePosition(buttonSlice.getCentre());
    
    mDistortionType.setSize(200, mDistortionType.getHeight());
    
    
    
    /*mDriveSlider->setBounds(((getWidth()/5.f) * 1.f) - (100/2.f), ((getHeight()/2.f) - (100/2.f)), 100, 100);
    mGainSlider->setBounds(((getWidth()/5) * 2) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mBlendSlider->setBounds(((getWidth()/5) * 3) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mVolumeSlider->setBounds(((getWidth()/5) * 4) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mDistortionType.setBounds((getWidth()/2), getHeight()/2,200, 20);*/
    
}


