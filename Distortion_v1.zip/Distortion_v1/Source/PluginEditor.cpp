/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#include "PluginProcessor.h"
#include "PluginEditor.h"

//==============================================================================
DistortionAudioProcessorEditor::DistortionAudioProcessorEditor (DistortionAudioProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    // Make sure that before the constructor has finished, you've set the
    // editor's size to whatever you need it to be.
    setSize (500, 200);
    
    addAndMakeVisible(mDriveSlider = new Slider("Drive"));
    mDriveSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mDriveSlider->setTextBoxStyle((Slider::TextEntryBoxPosition::NoTextBox), true, 0, 0);
    /*mRateSlider.setRange(rateParameter->range.start, rateParameter->range.end);
    mRateSlider.setValue(*rateParameter);*/
    
    addAndMakeVisible(mRangeSlider= new Slider("Range"));
    mRangeSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mRangeSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    
    addAndMakeVisible(mBlendSlider= new Slider("Blend"));
    mBlendSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mBlendSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    
    addAndMakeVisible(mVolumeSlider= new Slider("Volume"));
    mVolumeSlider->setSliderStyle(Slider::RotaryVerticalDrag);
    mVolumeSlider->setTextBoxStyle((Slider::NoTextBox), true, 0, 0);
    
    mDriveAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "drive", *mDriveSlider);
    mRangeAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "range", *mRangeSlider);
    mBlendAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "blend", *mBlendSlider);
    mVolumeAttachment = new AudioProcessorValueTreeState::SliderAttachment(p.getState(), "volume", *mVolumeSlider);
}

DistortionAudioProcessorEditor::~DistortionAudioProcessorEditor()
{
}

//==============================================================================
void DistortionAudioProcessorEditor::paint (Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (ResizableWindow::backgroundColourId));

    g.setColour (Colours::white);
    g.setFont (15.0f);
    //g.drawFittedText ("Hello World!", getLocalBounds(), Justification::centred, 1);
    g.drawText("Drive", ((getWidth()/5) * 1) - (100/2), ((getHeight()/2) +5), 100, 100, Justification::centred,true);
    g.drawText("Range", ((getWidth()/5) * 2) - (100/2), ((getHeight()/2) +5), 100, 100, Justification::centred,true);
    g.drawText("Blend", ((getWidth()/5) * 3) - (100/2), ((getHeight()/2) +5), 100, 100, Justification::centred);
    g.drawText("Volume", ((getWidth()/5) * 4) - (100/2), ((getHeight()/2) +5), 100, 100, Justification::centred);
}




void DistortionAudioProcessorEditor::resized()
{
    // This is generally where you'll want to lay out the positions of any
    // subcomponents in your editor..
    
    mDriveSlider->setBounds(((getWidth()/5) * 1) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mRangeSlider->setBounds(((getWidth()/5) * 2) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mBlendSlider->setBounds(((getWidth()/5) * 3) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    mVolumeSlider->setBounds(((getWidth()/5) * 4) - (100/2), ((getHeight()/2) - (100/2)), 100, 100);
    
}
