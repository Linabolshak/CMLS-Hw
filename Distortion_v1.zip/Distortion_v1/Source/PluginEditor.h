/*
  ==============================================================================

    This file was auto-generated!

    It contains the basic framework code for a JUCE plugin editor.

  ==============================================================================
*/

#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

//==============================================================================
/**
*/
class DistortionAudioProcessorEditor  : public AudioProcessorEditor
{
public:
    DistortionAudioProcessorEditor (DistortionAudioProcessor&);
    ~DistortionAudioProcessorEditor();

    //==============================================================================
    void paint (Graphics&) override;
    void resized() override;

private:
    // This reference is provided as a quick way for your editor to
    // access the processor object that created it.
    DistortionAudioProcessor& processor;
    
    /* Slider declaration */
    ScopedPointer<Slider> mDriveSlider;
    ScopedPointer<Slider> mRangeSlider;
    ScopedPointer<Slider> mBlendSlider;
    ScopedPointer<Slider> mVolumeSlider;
    
    /* Slider attachement declaration: for xml to save presets */
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mDriveAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mRangeAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mBlendAttachment;
    ScopedPointer<AudioProcessorValueTreeState::SliderAttachment> mVolumeAttachment;
    
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (DistortionAudioProcessorEditor)
};
